<?php
$arr = array(54,3,23,21,45,66,2,21,232,34,343,34,3,34);
$x = $arrr[0];
$tmp = '';
$lnth = 0;
while($lnth < $arr)
{
	$lnth++;
	echo $lnth;
	echo "<br>";
}

//for($a=1; $a<)
?>