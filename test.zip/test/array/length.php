<?php

//$a = array(21,23,23,23,23,23,23,3);
$str = "banvari lal";
$i = 0;
while(isset($str[$i]))
{
	$i++;
}
echo $i;
?>